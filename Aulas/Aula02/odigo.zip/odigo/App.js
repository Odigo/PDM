// Hook useState
import { useState } from 'react';

//Componente do react native
import { View, StyleSheet } from 'react-native'
import Box from './components/Box';

//Componente princicial do App
const App = () => (
  <View style={styles.container}>
  <Box size={50} color="blue" flex={1}></Box>
  <Box size={50} color="purple" flex={2}></Box>
  <Box size={50} color="yellow" flex={3}></Box>
  <Box size={50} color="grey" flex={3}></Box>
  <Box size={50} color="black" flex={4}></Box>
  <Box size={50} color="red" flex={5}></Box>
  <Box size={50} color="green" flex={6}></Box>
  </View>
);

// Estilo objeto StyleSheet
const styles = StyleSheet.create({
  container: {flex: 1,
  flexDirection: 'column',
  justifyContent: "space-evenly",
  alignItems: "stretch"},
});

export default App